# Sample Containerized Microservice
Includes Dockerfile, Redis caching, and pytest suite.